const http = require('http');
const fs = require('fs');

const server = http.createServer(function (req, res) {
    let data = '';
    res.setHeader('Access-Control-Allow-Origin', 'http://localhost:63342');
    res.setHeader('Content-Type', 'application/json;charset=utf-8');
    res.setHeader('Access-Control-Allow-Credentials', 'true');
    //res.setHeader('Access-Control-Allow-Origin', '*');
    //res.setHeader('Access-Control-Allow-Headers', 'origin, content-type, credentials');

    req.on('data', async (chunk) => {
        data += chunk;
        console.log('data: ', data);
    });

    req.on('end', async () => {
        console.log(+data);
      data = +data + 1;
      console.log('+data', data);
      let result = JSON.stringify(data);
      console.log('result', result);
        res.write(result);
        console.log('write');
        res.end();
        console.log('end');
    });
});
server.listen(3000);   
