let main = document.getElementsByClassName('main')[0];

main.addEventListener('click', (e) => {
    //console.log('inLinstener');
    const url = "http://localhost:3000";

    let counter = document.getElementById('counter');
    let goodsHtml = document.getElementsByClassName('add-to-cart');
    let goods = [];
    for (let index = 0; index < goodsHtml.length; index++) {
        goods[index] = goodsHtml[index];
    }


    if (goods.includes(e.target)) {
        console.log('inIf');
        fetch(url, {
            headers: {
                'Content-Type': 'application/json;charset=utf-8'
            },
            body: JSON.stringify(counter.innerHTML),
            method: 'POST',
        })
            .then((response) => {
                return response.json();
            })
            .then((data) => {
                //console.log('qwe');
                console.log(data);
            })
        console.log('endListener');
        // let data = response.json();
        // data = JSON.parse(data);
        // counter.innerHTML = data;
    } else {
        alert('Not found');
    }



    // if (goods.includes(e.target)) {
    //     console.log('inIf');
    //      fetch(url, {}).then((response) => {
    //          console.log("request is sent");
    //          return response.json();
    //      }).then((data)=>{
    //         console.log(data);
    //         counter.innerHTML = data;
    //      })
    // } else {
    //     alert('Not found');
    // }
})


